<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| SEO Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"description" => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut tortor rutrum massa efficitur tincidunt vel nec lacus. Curabitur porta aliquet diam, eu gravida neque lacinia.",
	"keywords" => "donaciones,soporte,creadores,sponzy,suscripción,contenido",
);
