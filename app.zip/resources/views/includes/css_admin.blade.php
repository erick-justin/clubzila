<!-- Bootstrap 3.3.5 -->
<link href="{{ asset('public/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
<!-- Font Awesome Icons -->
<link href="{{ asset('public/css/fontawesome.min.css')}}" rel="stylesheet" type="text/css" />
<!-- App css -->
<link href="{{ asset('public/admin/css/app.css')}}?v={{$settings->version}}" rel="stylesheet" type="text/css" />

 <!-- Theme style -->
<link href="{{ asset('public/admin/css/AdminLTE.min.css')}}?v={{$settings->version}}" rel="stylesheet" type="text/css" />
