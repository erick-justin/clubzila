package com.app.uaejobs.callbacks;

import com.app.uaejobs.models.Ads;

public class CallbackAds {

    public String status;
    public Ads ads = null;

}
