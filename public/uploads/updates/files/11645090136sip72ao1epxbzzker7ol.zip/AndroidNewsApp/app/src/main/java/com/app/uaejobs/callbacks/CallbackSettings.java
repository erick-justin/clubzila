package com.app.uaejobs.callbacks;

import com.app.uaejobs.models.Setting;

import java.io.Serializable;

public class CallbackSettings implements Serializable {

    public String status = "";
    public Setting post = null;

}