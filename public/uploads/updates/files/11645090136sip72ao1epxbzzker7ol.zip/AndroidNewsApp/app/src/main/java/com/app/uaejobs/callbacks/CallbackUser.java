package com.app.uaejobs.callbacks;

import com.app.uaejobs.models.User;

public class CallbackUser {

    public String status = "";
    public User response = null;

}