package com.app.uaejobs.models;

import java.io.Serializable;

public class Category implements Serializable {

    public long cid = -1;
    public String category_name = "";
    public String category_image = "";
    public long post_count = -1;

}
