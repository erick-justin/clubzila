package com.app.uaejobs.models;

public class Comments {

    public String comment_id = "";
    public String user_id = "";
    public String name = "";
    public String image = "";
    public String date_time = "";
    public String content = "";

}
