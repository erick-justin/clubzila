package com.app.uaejobs.models;

public class Value {

    public String value;
    public String message;

}